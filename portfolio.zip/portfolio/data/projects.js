// ─────────────────────────────────────────────
//  PROJECTS DATA
//
//  To ADD a project:    append a new object to the array below.
//  To REMOVE a project: delete its object from the array.
//  To REORDER:          drag the objects into a new order.
//
//  Index numbers (01, 02…) are generated automatically
//  from array position — you never need to renumber.
//
//  Fields:
//  ┌─────────────┬──────────────────────────────────────────────────┐
//  │ title       │ Project name                                      │
//  │ sub         │ One-line descriptor shown in the collapsed row    │
//  │ tags        │ Array of short label strings (max ~3)            │
//  │ year        │ String, shown inside the expanded panel          │
//  │ image       │ Path to image file, or null for placeholder      │
//  │ description │ Paragraph shown in the expanded panel            │
//  │ links       │ Array of { label, icon, href }                   │
//  │             │   icon options: 'external-link' | 'github' |     │
//  │             │   'download' | 'file-text' | 'arrow-right'       │
//  └─────────────┴──────────────────────────────────────────────────┘
// ─────────────────────────────────────────────

export const projects = [
  {
    title:       'Generative Type System',
    sub:         'Algorithmic typography generator',
    tags:        ['Generative', 'Canvas'],
    year:        '2025',
    image:       null, // e.g. './assets/gen-type.jpg'
    description: 'A browser-based tool that constructs typefaces from mathematical rules. Each glyph emerges from a set of editable parameters — stroke weight, tension, terminal style — producing type systems that feel both alien and legible.',
    links: [
      { label: 'Live demo', icon: 'external-link', href: '#' },
      { label: 'Source',    icon: 'github',        href: '#' },
    ],
  },
  {
    title:       'Field Notes',
    sub:         'Minimal capture tool for wandering minds',
    tags:        ['App', 'Tool'],
    year:        '2025',
    image:       null,
    description: 'A note-taking app built around the idea that capture should have zero friction. No folders, no tags, no hierarchy — just a single chronological stream with fast full-text search. Ships as a native macOS menubar app.',
    links: [
      { label: 'Download',   icon: 'download',   href: '#' },
      { label: 'Case study', icon: 'file-text',  href: '#' },
    ],
  },
  {
    title:       'Noise Garden',
    sub:         'Interactive Perlin noise sculptures',
    tags:        ['Generative', 'WebGL'],
    year:        '2024',
    image:       null,
    description: 'An ongoing series of web-based generative works using multi-layered Perlin noise fields. Each piece is deterministic but infinite — seeded by a hash so any state can be revisited and shared via URL.',
    links: [
      { label: 'Explore', icon: 'external-link', href: '#' },
    ],
  },
  {
    title:       'Palette Engine',
    sub:         'Perceptually-uniform colour tools',
    tags:        ['App', 'Tool'],
    year:        '2024',
    image:       null,
    description: 'A colour palette generator that works in OKLCH space rather than HSL, producing gradients that look balanced at every lightness step. Exports to Tailwind config, CSS custom properties, or Figma tokens.',
    links: [
      { label: 'Live tool', icon: 'external-link', href: '#' },
      { label: 'Source',    icon: 'github',        href: '#' },
    ],
  },
];
