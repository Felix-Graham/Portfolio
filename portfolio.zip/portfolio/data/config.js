// ─────────────────────────────────────────────
//  SITE CONFIG
//  Edit this file to update your identity,
//  bio, social links, and availability status.
// ─────────────────────────────────────────────

export const config = {
  name:      'Your Name',
  role:      'Creative Developer',
  location:  'UK',

  // Set to true to show the "Available for select projects" status dot
  available: true,

  // Shown in the hero section
  headline: ['Building things', 'that <em>think</em>', 'and move.'],
  bio: 'Apps, tools, and generative systems. I make software that has character — precise where it needs to be, expressive where it wants to be.',

  // Footer + nav links
  social: {
    github:  'https://github.com/yourhandle',
    twitter: 'https://twitter.com/yourhandle',
    email:   'you@example.com',
  },

  // Copyright year (set manually or use new Date().getFullYear())
  year: 2025,
};
